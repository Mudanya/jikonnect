-- AlterEnum
ALTER TYPE "ConversationType" ADD VALUE 'SUPER_ADMIN';
