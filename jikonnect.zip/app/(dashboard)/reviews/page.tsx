
const Reviews = () => {
  return (
    <div>Reviews</div>
  )
}

export default Reviews