import { config } from 'dotenv';
config({ path: '.env' });
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
};

export default nextConfig;
