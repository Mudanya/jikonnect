declare module "*.css";
declare module 'jsonwebtoken';
