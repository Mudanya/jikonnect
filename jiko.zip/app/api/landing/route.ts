import { transporter } from '@/lib/email';
import logger from '@/lib/logger';
import { getSettingsByKey } from '@/services/queries/admin.query';
import { completedBookings, getAllProviders, getAvgRatingResult, getProviderServices, getRecentReviews, totalBookings, totalProviders, totalReviews, verifiedProviders } from '@/services/queries/client.query';
import { NextRequest, NextResponse } from 'next/server';


export const GET = async (request: NextRequest) => {
    try {


        // Calculate average rating
        const avgRatingResult = await getAvgRatingResult()


        const averageRating = avgRatingResult._avg.rating || 0;

        // Get top-rated providers with their services
        const topProviders = await getAllProviders()
        console.error('top', topProviders)

        // Get recent reviews with booking and reviewer info
        const recentReviews = await getRecentReviews()

        // Get service categories with provider counts
        const allProviders = await getProviderServices()

        const platformDetails = await getSettingsByKey('platform')

        // Count providers by category
        // const categoryMap = new Map<string, number, string>();
        // allProviders.forEach(provider => {
        //     provider.profile?.services.forEach(category => {
        //         categoryMap.set(category.name, (categoryMap.get(category.name) || 0) + 1, category.description!);
        //     });
        // });

        // const serviceCategories = Array.from(categoryMap.entries()).map(([name, count]) => ({
        //     name,
        //     count,
        //     description: getCategoryDescription(name)
        // })).sort((a, b) => b.count - a.count);

        return NextResponse.json({
            success: true,
            data: {
                stats: {
                    totalProviders,
                    verifiedProviders,
                    totalBookings,
                    completedBookings,
                    totalReviews,
                    averageRating: Number(averageRating.toFixed(1))
                },
                topProviders: topProviders.map(p => ({
                    id: p.id,
                    title: p.services[0],
                    name: p.firstName + " " + p.lastName,
                    avatar: p.avatar,
                    rating: p.rating,
                    location: p.location,
                    categories: p.services,
                    bio: p.bio
                })),
                recentReviews: recentReviews.map(r => ({
                    id: r.id,
                    rating: r.rating,
                    comment: r.comment,
                    createdAt: r.createdAt,
                    reviewerName: r.reviewer.firstName + " " + r.reviewer.lastName,
                    reviewerAvatar: r.reviewer.avatar,
                    providerTitle: r.reviewee.profile?.services[0],
                    providerLocation: r.reviewee.profile?.location?.name,
                    serviceDate: r.booking.scheduledDate
                })),
                serviceCategories: allProviders.map(provider => provider?.profile?.services || []).flat().slice(0, 4), // Top 4 categories,
                platform: { name: platformDetails?.platformName, phone: platformDetails?.supportPhone, email: platformDetails?.supportEmail }
            }
        });

    } catch (error) {
        logger.error('Failed to fetch landing page data: ' + (error as Error).message);
        console.log(error)
        return NextResponse.json(
            { success: false, error: 'Failed to fetch landing page data' },
            { status: 500 }
        );
    }
}

export const POST = async (req: NextRequest) => {

    try {
        const res = await transporter.sendMail({
            from: `${process.env.SMTP_FROM}`,
            to: 'nmudanya9@gmail.com',
            subject: 'Verify Email',
            html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Email Verification</h1>
        <p>Test email</p>
       
        <p style="color: #666; font-size: 14px;">
          This link will expire in 24 hours.
        </p>
      </div>
    `
        })
        console.log('email res', res)
        return NextResponse.json({ success: true, message: 'sent' })
    }
    catch (err) {
        logger.error((err as Error).message)
        return NextResponse.json({ success: false, message: 'error' }, { status: 500 })
    }
}